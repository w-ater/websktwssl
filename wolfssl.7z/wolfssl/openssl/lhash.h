/* lhash.h for openSSL */

